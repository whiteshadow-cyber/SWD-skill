# swd - Claude skill for the CSE-2340 coding format

A Claude skill that makes Claude write web pages in the CSE-2340 Software Development 1 class format:

- single-file HTML with the Tailwind CSS v4 browser CDN (or plain CSS with media queries)
- semantic tags, descriptive ids and numbered section comments
- mobile-first responsive layout
- beginner-friendly JavaScript (arrays of objects, DOM rendering, events)
- a README and ZIP for assignment submissions

## Install

1. Download `swd.skill` from this repo (open the file, then click the download button).
2. In Claude (claude.ai or the app), open the skills settings and upload `swd.skill`.
   Skills need a Claude plan that supports them.

## Use

Start a message with `swd`, for example:

- `swd: make a landing page for a gym`
- `swd: here is my MP2 brief` (attach the PDF)
- `swd: explain this code in the class style`

## What's inside

- `swd/SKILL.md` - the rules Claude follows
- `swd/assets/starter.html` - a complete example page in this format
- `swd.skill` - the packaged file you upload to Claude

## Note

This is an unofficial student-made helper. Always check your assignment brief and make sure you understand the code you submit.
