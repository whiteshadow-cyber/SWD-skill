---
name: swd
description: Build web pages in the CSE-2340 Software Development 1 (SWD) class coding format - single-file HTML with Tailwind CSS v4 browser CDN (or plain CSS with media queries), semantic HTML, descriptive ids, numbered section comments, mobile-first responsive layout, and beginner-friendly JavaScript. Use this skill whenever the user says "swd", mentions CSE-2340, Software Development 1, MP1/MP2/mini project, class code, lab task, CT practice, or asks for any HTML, CSS, Tailwind or basic JavaScript page, website, dashboard, portfolio, landing page or assignment that should match their class style, even if they do not mention the format.
---

# SWD coding format

Pages for the CSE-2340 class follow one consistent, beginner-readable style. Match it exactly so the work looks like the class examples and the student can explain every line.

## Before writing

1. If the user attached an assignment or lab brief, read it first and list its requirements (marks, individual or group, required elements, what to submit). Build to those requirements and check them at the end.
2. If the topic is open ("a website of your choice"), pick one concrete subject and go. Do not ask first. Say the assumption in one line afterwards.
3. Choose the stack: **Tailwind** by default. Use **plain CSS** only if the user asks for CSS, Flexbox, Grid or media queries practice.

## File format rules (both stacks)

- One `index.html` (or `w{week}_c{class}_{topic}.html` for class practice files). Plain CSS goes in a separate `.css` file in the same folder.
- Start with `<!DOCTYPE html>`, `<html lang="en">`, `meta charset`, `meta viewport`, and a `<title>`.
- 4-space indentation, one blank line between blocks, attributes on separate lines when a tag gets long.
- Semantic tags: `header`, `nav aria-label="Main navigation"`, `main`, `section`, `article`, `aside`, `footer`, `time`. Never a wall of `div`s.
- Give every major element a descriptive `id` (`id="course-grid"`, `id="stat-pending-tasks"`).
- Number section comments: `<!-- 1. NAVIGATION BAR -->`, `<!-- 2. HERO SECTION -->`.
- Accessibility basics: every input has a `<label for>`, every image has real `alt` text, buttons use `<button>`, keyboard focus is visible.
- Mobile-first. Content is one column by default and gains columns at breakpoints.
- Use realistic content and never invent claims about the user (awards, jobs, results). Fictional businesses must say so in the footer.

## Tailwind stack

- Load with `<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>` in `<head>`. No build step, no config.
- Style with utility classes only, using arbitrary values for colors and sizes: `bg-[#111827]`, `text-[#64748b]`, `p-[22px]`, `grid-cols-[60px_1fr]`.
- Breakpoints: `md:` (768px) for tablet and `min-[1100px]:` for desktop sidebar layouts; `min-[1400px]:max-w-[1500px]` for large screens.
- Hover and focus: `hover:bg-[...]`, `hover:-translate-y-1 transition-transform duration-200`, `focus-visible:outline-[3px] focus-visible:outline-offset-2 focus-visible:outline-[#...]`.
- Do not leave semantic classes (`sidebar`, `nav-link`) that have no CSS behind them unless used by JavaScript.
- Fonts: Google Fonts `<link>` with a fallback stack, e.g. `font-['DM_Sans',Arial,sans-serif]`.

## Plain CSS stack

- External stylesheet with banner comments per block (`/* SIDEBAR */`, `/* COURSE GRID */`).
- Start with `* { box-sizing: border-box; }` and a `body` reset.
- Write the mobile layout first, then add `@media (min-width: 768px)` (tablet), `@media (min-width: 1100px)` (desktop), `@media (min-width: 1400px)` (large).
- Use Flexbox for one-dimensional rows and CSS Grid for page and card layouts. Comment pseudo-classes (`:hover`, `:focus-visible`).
- Class names describe the thing (`.course-card`, `.stat-label`), not the look.

## JavaScript (inline `<script>` at the end of `<body>`)

- Teaching order with numbered comments: `// 1. VARIABLES`, `// 2. OBJECT`, `// 3. ARRAY`, `// 4. TEMPLATE LITERAL`, `// 5. FUNCTION`, `// 6. DOM + ARRAY LOOP`, `// 7. EVENT`. Use only the steps the page needs.
- `const` by default, `let` only when the value changes. Arrow functions and template literals are fine.
- Prefer data in an array of objects, then `forEach` + `document.createElement` + `innerHTML` to render cards. Hardcoded data only; never put user input into `innerHTML` (use `textContent`).
- Events with `addEventListener`. Use event delegation (one listener checking `event.target.classList.contains(...)`) when many similar elements exist.
- Typical interactive elements to include: mobile menu toggle with `aria-expanded`, tab or filter buttons, form validation that shows a message in a `role="status"` paragraph (no `alert` for finished work).
- No libraries, no frameworks, no `localStorage` unless asked.

## Reference example

`assets/starter.html` is a complete, working page in this format (sticky nav with mobile toggle, hero, a JavaScript-rendered filterable menu, info cards, validated form, footer). Reuse its structure, comment numbering and script patterns, then replace the subject, content and colors for the new page. Do not copy its restaurant content into an unrelated page.

## Delivering

1. Write files to `/mnt/user-data/outputs/` and present them.
2. For assignments, also add a short `README.md` (course, assessment, requirements covered, how to run) and zip the project folder.
3. Tell the user which requirement each part covers, what content was invented and should be edited, and that the page needs internet for the Tailwind CDN and fonts.
4. For graded individual work, remind them to make sure they can explain the code.
5. Do not claim the page was tested in a browser unless it was.
